import React, { Component } from 'react';

import {
    Image,
    View,
    Text,
    AsyncStorage,
    StyleSheet,
    ImageBackground,
    Dimensions
 
} from 'react-native';

import { Actions } from 'react-native-router-flux';
import AppIntro from "../AppIntro/AppIntro"
// import CommonStyles from '../../CommonStyle/CommonStyle';
 import Colors from '../../Constants/Colors';
// import Strings from '../../Constants/Strings';
// import ImagePath from '../../Constants/ImagesPath';
import STRINGS from '../../Constants/Strings';
import Spinner from 'react-native-spinkit';
const window = Dimensions.get('window');

class SplashScreen extends Component {

    constructor() {
        super();
        this.state = {
           userInfo:{},
           isSpinnerVisible:false
        };
    }

componentWillMount() {
    
   this.getUserData()
     
    }

    getUserData(){
        this.setState({isSpinnerVisible:true})
        AsyncStorage.getItem("UserInfo").then((value) => {
            console.log("AsyncValue>>>>"+value);
    
          if (value) {
              var userData = JSON.parse(value);
              this.setState({userInfo:userData});
              setTimeout(() => {
                this.redirect(userData.savedScreen) 
             }, 2000);
             
            
          }
      }).done();
    
    }
    
    redirect(savedScreen){
        this.setState({isSpinnerVisible:false})
      switch(savedScreen){
        case STRINGS.SCREEN_ONE:
        Actions.contact({type:'reset'})
        break;
        case STRINGS.SCREEN_TWO:
        Actions.servicePreferences({type:'reset'})
        break;
        case STRINGS.SCREEN_THREE:
        Actions.pregnancyselection({type:'reset'})
        break;
        case STRINGS.SCREEN_THREE_NO:
        Actions.whattobuy({type:'reset'})
        break;
        case STRINGS.SCREEN_THREE_YES:
        Actions.kidsselection({type:'reset'})
        break;
        case STRINGS.SCREEN_FOUR:
        Actions.childDobInformation({type:'reset'})
        break;
        case STRINGS.SCREEN_SIX:
        Actions.sizeandproportion({type:'reset'})
        break;
        case STRINGS.SCREEN_SEVEN:
        Actions.brandSelection({type:'reset'})
        break;
        case STRINGS.SCREEN_EIGHT:
        Actions.talktoUs({type:'reset'})
        break;
        default:
        Actions.appIntro({type:'reset'})
        
      }
    }
       

 render() {
   
        return (
            <View>
            <Spinner
            isVisible={this.state.isSpinnerVisible}
            style={{position:'absolute',alignSelf:'center',top:window.height/2}} type="FadingCircleAlt" color={Colors.BUTTON_COLOR}
           
            />
            </View>
         
        );
    }

}

export default SplashScreen;

const styles = StyleSheet.create({

   imgBackground: {
    width: '100%',
    height: '100%',
    flex: 1 
  },
  });