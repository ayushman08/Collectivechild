const API_CONST = {

    N_USER_SIGNUP 						: 'N_USER_SIGNUP',
    N_SERVICE_PREF                      :  'N_SERVICE_PREF',
    N_SELECT_KIDS                       : 'N_SELECT_KIDS',
    N_GET_BRANDS_LIST                   : 'N_GET_BRANDS',
    N_SELECT_WHO_WILL_DECIDE            : 'N_SELECT_WHO_WILL_DECIDE',
    N_GET_SIZES                         : 'N_GET_SIZES',
    N_SELECT_SIZE_AND_PROPORTION        : 'N_SELECT_SIZE_AND_PROPORTION',
    N_SEND_BRANDS_DATA                  : 'N_SEND_BRANDS_DATA',
    N_DOB_SELECT                        :  'N_DOB_SELECT',
    N_DUEDATE_SELECT                    :  'N_DUEDATE_SELECT',
    N_GET_STYLE_LIST                    :  'N_GET_STYLE_LIST',


}
export default API_CONST
